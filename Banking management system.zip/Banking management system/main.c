#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ACCOUNT_FILE "accounts.dat"
#define TRANSACTION_FILE "transactions.dat"
#define MAX_NAME_LENGTH 50
#define MAX_PASSWORD_LENGTH 20

// UI element identifiers
#define IDC_CREATE_ACC_BTN 1001
#define IDC_LIST_ACC_BTN 1002
#define IDC_DEPOSIT_BTN 1003
#define IDC_WITHDRAW_BTN 1004
#define IDC_CHECK_BALANCE_BTN 1005
#define IDC_UPDATE_PASSWORD_BTN 1006
#define IDC_VIEW_TRANSACTIONS_BTN 1007
#define IDC_DELETE_ACC_BTN 1008
#define IDC_ACC_NO_EDIT 1009
#define IDC_NAME_EDIT 1010
#define IDC_PASSWORD_EDIT 1011
#define IDC_AMOUNT_EDIT 1012
#define IDC_NEW_PASSWORD_EDIT 1013
#define IDC_ACC_LIST 1014

// Account structure
typedef struct {
    int acc_no;
    char name[MAX_NAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    double balance;
} Account;

// Transaction structure
typedef struct {
    int acc_no;
    char type[10];
    double amount;
    char date[20];
} Transaction;

// Global variables
HWND hAccNoEdit, hNameEdit, hPasswordEdit, hAmountEdit, hNewPasswordEdit, hAccList;

// Function prototypes
void create_account(HWND hWnd);
void list_accounts(HWND hWnd);
void deposit_money(HWND hWnd);
void withdraw_money(HWND hWnd);
void check_balance(HWND hWnd);
void update_password(HWND hWnd);
void view_transactions(HWND hWnd);
void delete_account(HWND hWnd);
int validate_account(int acc_no, const char *entered_password, Account *found_acc, FILE *file);
void log_transaction(int acc_no, const char *type, double amount);
void show_error_message(HWND hWnd, const char *message);
void clear_input_fields(HWND hWnd);

// Function to validate account credentials
int validate_account(int acc_no, const char *entered_password, Account *found_acc, FILE *file) {
    rewind(file);
    Account acc;

    while (fread(&acc, sizeof(Account), 1, file)) {
        if (acc.acc_no == acc_no) {
            if (strcmp(acc.password, entered_password) == 0) {
                *found_acc = acc;
                return ftell(file) - sizeof(Account);
            } else {
                show_error_message(NULL, "Incorrect password!");
                return -1;
            }
        }
    }

    show_error_message(NULL, "Account number not found!");
    return -1;
}

// Function to log transactions
void log_transaction(int acc_no, const char *type, double amount) {
    FILE *file = fopen(TRANSACTION_FILE, "ab");
    if (file == NULL) {
        show_error_message(NULL, "Unable to open transaction file!");
        return;
    }

    Transaction trans;
    trans.acc_no = acc_no;
    strcpy(trans.type, type);
    trans.amount = amount;
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(trans.date, "%02d-%02d-%04d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);

    fwrite(&trans, sizeof(Transaction), 1, file);
    fclose(file);
}

// Function to clear input fields
void clear_input_fields(HWND hWnd) {
    SetWindowText(hAccNoEdit, "");
    SetWindowText(hNameEdit, "");
    SetWindowText(hPasswordEdit, "");
    SetWindowText(hAmountEdit, "");
    SetWindowText(hNewPasswordEdit, "");
}

// Function to create a new account
void create_account(HWND hWnd) {
    FILE *file = fopen(ACCOUNT_FILE, "ab");
    if (file == NULL) {
        show_error_message(hWnd, "Unable to open file!");
        return;
    }

    Account acc;
    char accNoStr[20], name[MAX_NAME_LENGTH], password[MAX_PASSWORD_LENGTH];

    GetWindowText(hAccNoEdit, accNoStr, sizeof(accNoStr));
    GetWindowText(hNameEdit, name, sizeof(name));
    GetWindowText(hPasswordEdit, password, sizeof(password));

    acc.acc_no = atoi(accNoStr);
    strncpy(acc.name, name, sizeof(acc.name) - 1);
    strncpy(acc.password, password, sizeof(acc.password) - 1);
    acc.balance = 0.0;

    if (fwrite(&acc, sizeof(Account), 1, file) != 1) {
        show_error_message(hWnd, "Failed to write account to file!");
    }

    fclose(file);
    MessageBox(hWnd, "Account created successfully!", "Success", MB_OK | MB_ICONINFORMATION);

    // Clear input fields
    clear_input_fields(hWnd);
}

// Function to list all accounts
void list_accounts(HWND hWnd) {
    FILE *file = fopen(ACCOUNT_FILE, "rb");
    if (file == NULL) {
        show_error_message(hWnd, "Unable to open file!");
        return;
    }

    Account acc;
    char buffer[256];
    SendMessage(hAccList, LB_RESETCONTENT, 0, 0);

    while (fread(&acc, sizeof(Account), 1, file)) {
        snprintf(buffer, sizeof(buffer), "Acc No: %d, Name: %s, Balance: Rs.%.2lf", acc.acc_no, acc.name, acc.balance);
        SendMessage(hAccList, LB_ADDSTRING, 0, (LPARAM)buffer);
    }

    fclose(file);
}

// Function to deposit money into an account
void deposit_money(HWND hWnd) {
    FILE *file = fopen(ACCOUNT_FILE, "rb+");
    if (file == NULL) {
        show_error_message(hWnd, "Unable to open file!");
        return;
    }

    int acc_no;
    char accNoStr[20], entered_password[MAX_PASSWORD_LENGTH], amountStr[20];
    double amount;
    Account acc;

    GetWindowText(hAccNoEdit, accNoStr, sizeof(accNoStr));
    GetWindowText(hPasswordEdit, entered_password, sizeof(entered_password));
    GetWindowText(hAmountEdit, amountStr, sizeof(amountStr));

    acc_no = atoi(accNoStr);
    amount = atof(amountStr);

    int pos = validate_account(acc_no, entered_password, &acc, file);
    if (pos == -1) {
        fclose(file);
        return;
    }

    if (amount <= 0) {
        show_error_message(hWnd, "Invalid deposit amount!");
        fclose(file);
        return;
    }

    acc.balance += amount;
    fseek(file, pos, SEEK_SET);
    fwrite(&acc, sizeof(Account), 1, file);
    fflush(file);
    fclose(file);

    log_transaction(acc_no, "Deposit", amount);
    MessageBox(hWnd, "Deposit successful!", "Success", MB_OK | MB_ICONINFORMATION);

    // Clear input fields
    clear_input_fields(hWnd);
}

// Function to withdraw money from an account
void withdraw_money(HWND hWnd) {
    FILE *file = fopen(ACCOUNT_FILE, "rb+");
    if (file == NULL) {
        show_error_message(hWnd, "Unable to open file!");
        return;
    }

    int acc_no;
    char accNoStr[20], entered_password[MAX_PASSWORD_LENGTH], amountStr[20];
    double amount;
    Account acc;

    GetWindowText(hAccNoEdit, accNoStr, sizeof(accNoStr));
    GetWindowText(hPasswordEdit, entered_password, sizeof(entered_password));
    GetWindowText(hAmountEdit, amountStr, sizeof(amountStr));

    acc_no = atoi(accNoStr);
    amount = atof(amountStr);

    int pos = validate_account(acc_no, entered_password, &acc, file);
    if (pos == -1) {
        fclose(file);
        return;
    }

    if (amount <= 0 || amount > acc.balance) {
        show_error_message(hWnd, "Invalid withdrawal amount or insufficient balance!");
        fclose(file);
        return;
    }

    acc.balance -= amount;
    fseek(file, pos, SEEK_SET);
    fwrite(&acc, sizeof(Account), 1, file);
    fflush(file);
    fclose(file);

    log_transaction(acc_no, "Withdraw", amount);
    MessageBox(hWnd, "Withdrawal successful!", "Success", MB_OK | MB_ICONINFORMATION);

    // Clear input fields
    clear_input_fields(hWnd);
}

// Function to check account balance
void check_balance(HWND hWnd) {
    FILE *file = fopen(ACCOUNT_FILE, "rb");
    if (file == NULL) {
        show_error_message(hWnd, "Unable to open file!");
        return;
    }

    int acc_no;
    char accNoStr[20], entered_password[MAX_PASSWORD_LENGTH];
    Account acc;

    GetWindowText(hAccNoEdit, accNoStr, sizeof(accNoStr));
    GetWindowText(hPasswordEdit, entered_password, sizeof(entered_password));

    acc_no = atoi(accNoStr);

    if (validate_account(acc_no, entered_password, &acc, file) != -1) {
        char balanceStr[50];
        snprintf(balanceStr, sizeof(balanceStr), "Current Balance: Rs.%.2lf", acc.balance);
        MessageBox(hWnd, balanceStr, "Balance", MB_OK | MB_ICONINFORMATION);
    }

    fclose(file);

    // Clear input fields
    clear_input_fields(hWnd);
}

// Function to update account password
void update_password(HWND hWnd) {
    FILE *file = fopen(ACCOUNT_FILE, "rb+");
    if (file == NULL) {
        show_error_message(hWnd, "Unable to open file!");
        return;
    }

    int acc_no;
    char accNoStr[20], entered_password[MAX_PASSWORD_LENGTH], new_password[MAX_PASSWORD_LENGTH];
    Account acc;

    GetWindowText(hAccNoEdit, accNoStr, sizeof(accNoStr));
    GetWindowText(hPasswordEdit, entered_password, sizeof(entered_password));
    GetWindowText(hNewPasswordEdit, new_password, sizeof(new_password));

    acc_no = atoi(accNoStr);

    int pos = validate_account(acc_no, entered_password, &acc, file);
    if (pos == -1) {
        fclose(file);
        return;
    }

    strncpy(acc.password, new_password, sizeof(acc.password) - 1);
    fseek(file, pos, SEEK_SET);
    fwrite(&acc, sizeof(Account), 1, file);
    fflush(file);
    fclose(file);

    MessageBox(hWnd, "Password updated successfully!", "Success", MB_OK | MB_ICONINFORMATION);

    // Clear input fields
    clear_input_fields(hWnd);
}

// Function to view transaction history
void view_transactions(HWND hWnd) {
    FILE *file = fopen(TRANSACTION_FILE, "rb");
    if (file == NULL) {
        show_error_message(hWnd, "Unable to open transaction file!");
        return;
    }

    int acc_no;
    char accNoStr[20];
    GetWindowText(hAccNoEdit, accNoStr, sizeof(accNoStr));
    acc_no = atoi(accNoStr);

    Transaction trans;
    char buffer[256];
    SendMessage(hAccList, LB_RESETCONTENT, 0, 0);

    while (fread(&trans, sizeof(Transaction), 1, file)) {
        if (trans.acc_no == acc_no) {
            snprintf(buffer, sizeof(buffer), "Date: %s, Type: %s, Amount: Rs.%.2lf", trans.date, trans.type, trans.amount);
            SendMessage(hAccList, LB_ADDSTRING, 0, (LPARAM)buffer);
        }
    }

    fclose(file);

    // Clear input fields
    clear_input_fields(hWnd);
}

// Function to delete an account
void delete_account(HWND hWnd) {
    FILE *file = fopen(ACCOUNT_FILE, "rb");
    if (file == NULL) {
        show_error_message(hWnd, "Unable to open file!");
        return;
    }

    int acc_no;
    char accNoStr[20], entered_password[MAX_PASSWORD_LENGTH];
    Account acc;
    int found = 0;

    GetWindowText(hAccNoEdit, accNoStr, sizeof(accNoStr));
    GetWindowText(hPasswordEdit, entered_password, sizeof(entered_password));

    acc_no = atoi(accNoStr);

    int pos = validate_account(acc_no, entered_password, &acc, file);
    if (pos != -1) {
        found = 1;
    }

    fclose(file);

    if (found) {
        // Create a temporary file to store other accounts
        FILE *temp_file = fopen("temp.dat", "wb");
        file = fopen(ACCOUNT_FILE, "rb");
        Account temp_acc;

        while (fread(&temp_acc, sizeof(Account), 1, file)) {
            if (temp_acc.acc_no != acc_no) {
                fwrite(&temp_acc, sizeof(Account), 1, temp_file);
            }
        }

        fclose(file);
        fclose(temp_file);
        remove(ACCOUNT_FILE);
        rename("temp.dat", ACCOUNT_FILE);
        MessageBox(hWnd, "Account deleted successfully!", "Success", MB_OK | MB_ICONINFORMATION);
    } else {
        show_error_message(hWnd, "Account number or password is incorrect!");
    }

    // Clear input fields
    clear_input_fields(hWnd);
}

// Function to show error messages
void show_error_message(HWND hWnd, const char *message) {
    MessageBox(hWnd, message, "Error", MB_OK | MB_ICONERROR);
}

// Window procedure
LRESULT CALLBACK WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_CREATE_ACC_BTN:
                    create_account(hWnd);
                    break;
                case IDC_LIST_ACC_BTN:
                    list_accounts(hWnd);
                    break;
                case IDC_DEPOSIT_BTN:
                    deposit_money(hWnd);
                    break;
                case IDC_WITHDRAW_BTN:
                    withdraw_money(hWnd);
                    break;
                case IDC_CHECK_BALANCE_BTN:
                    check_balance(hWnd);
                    break;
                case IDC_UPDATE_PASSWORD_BTN:
                    update_password(hWnd);
                    break;
                case IDC_VIEW_TRANSACTIONS_BTN:
                    view_transactions(hWnd);
                    break;
                case IDC_DELETE_ACC_BTN:
                    delete_account(hWnd);
                    break;
            }
            break;
        case WM_DESTROY:
            PostQuitMessage(0);
            break;
        default:
            return DefWindowProc(hWnd, uMsg, wParam, lParam);
    }
    return 0;
}

// WinMain function
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    const char CLASS_NAME[] = "BankingSystemClass";

    WNDCLASS wc = { };
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;

    RegisterClass(&wc);

    HWND hWnd = CreateWindowEx(
        0,
        CLASS_NAME,
        "Banking System",
        WS_OVERLAPPEDWINDOW | WS_VSCROLL,
        CW_USEDEFAULT, CW_USEDEFAULT, 600, 400,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    if (hWnd == NULL) {
        return 0;
    }

    ShowWindow(hWnd, nCmdShow);

    // Create UI elements
    CreateWindow("STATIC", "Account Number:", WS_VISIBLE | WS_CHILD, 20, 20, 100, 20, hWnd, NULL, NULL, NULL);
    hAccNoEdit = CreateWindow("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 130, 20, 100, 20, hWnd, (HMENU)IDC_ACC_NO_EDIT, NULL, NULL);

    CreateWindow("STATIC", "Name:", WS_VISIBLE | WS_CHILD, 20, 50, 100, 20, hWnd, NULL, NULL, NULL);
    hNameEdit = CreateWindow("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 130, 50, 100, 20, hWnd, (HMENU)IDC_NAME_EDIT, NULL, NULL);

    CreateWindow("STATIC", "Password:", WS_VISIBLE | WS_CHILD, 20, 80, 100, 20, hWnd, NULL, NULL, NULL);
    hPasswordEdit = CreateWindow("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_PASSWORD, 130, 80, 100, 20, hWnd, (HMENU)IDC_PASSWORD_EDIT, NULL, NULL);

    CreateWindow("STATIC", "Amount:", WS_VISIBLE | WS_CHILD, 20, 110, 100, 20, hWnd, NULL, NULL, NULL);
    hAmountEdit = CreateWindow("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER, 130, 110, 100, 20, hWnd, (HMENU)IDC_AMOUNT_EDIT, NULL, NULL);

    CreateWindow("STATIC", "New Password:", WS_VISIBLE | WS_CHILD, 20, 140, 100, 20, hWnd, NULL, NULL, NULL);
    hNewPasswordEdit = CreateWindow("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_PASSWORD, 130, 140, 100, 20, hWnd, (HMENU)IDC_NEW_PASSWORD_EDIT, NULL, NULL);

    CreateWindow("BUTTON", "Create Account", WS_VISIBLE | WS_CHILD, 20, 170, 120, 30, hWnd, (HMENU)IDC_CREATE_ACC_BTN, NULL, NULL);
    CreateWindow("BUTTON", "List Accounts", WS_VISIBLE | WS_CHILD, 150, 170, 120, 30, hWnd, (HMENU)IDC_LIST_ACC_BTN, NULL, NULL);
    CreateWindow("BUTTON", "Deposit", WS_VISIBLE | WS_CHILD, 280, 170, 120, 30, hWnd, (HMENU)IDC_DEPOSIT_BTN, NULL, NULL);
    CreateWindow("BUTTON", "Withdraw", WS_VISIBLE | WS_CHILD, 410, 170, 120, 30, hWnd, (HMENU)IDC_WITHDRAW_BTN, NULL, NULL);
    CreateWindow("BUTTON", "Check Balance", WS_VISIBLE | WS_CHILD, 20, 210, 120, 30, hWnd, (HMENU)IDC_CHECK_BALANCE_BTN, NULL, NULL);
    CreateWindow("BUTTON", "Update Password", WS_VISIBLE | WS_CHILD, 150, 210, 120, 30, hWnd, (HMENU)IDC_UPDATE_PASSWORD_BTN, NULL, NULL);
    CreateWindow("BUTTON", "View Transactions", WS_VISIBLE | WS_CHILD, 280, 210, 120, 30, hWnd, (HMENU)IDC_VIEW_TRANSACTIONS_BTN, NULL, NULL);
    CreateWindow("BUTTON", "Delete Account", WS_VISIBLE | WS_CHILD, 410, 210, 120, 30, hWnd, (HMENU)IDC_DELETE_ACC_BTN, NULL, NULL);

    CreateWindow("LISTBOX", "", WS_VISIBLE | WS_CHILD | WS_BORDER | LBS_NOTIFY | WS_VSCROLL, 20, 250, 560, 100, hWnd, (HMENU)IDC_ACC_LIST, NULL, NULL);
    hAccList = GetDlgItem(hWnd, IDC_ACC_LIST);

    // Run the message loop
    MSG msg = { };
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}
